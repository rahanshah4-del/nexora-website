<?php
/**
 * Plugin Name:       Nexora AI Search Audit Tools
 * Plugin URI:        https://nexorasolution.us/tools/geo-audit/
 * Description:       Apply the fixes an AI search audit finds: robots.txt rules for AI crawlers, an llms.txt file, and Organization/WebSite schema, from one settings page.
 * Version:           1.1.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Nexora Solution
 * Author URI:        https://nexorasolution.us/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       nexora-ai-search-audit-tools
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NXSAT_VERSION', '1.1.1' );
define( 'NXSAT_FILE', __FILE__ );
define( 'NXSAT_OPTION', 'nxsat_options' );
define( 'NXSAT_AUDIT_URL', 'https://nexorasolution.us/tools/geo-audit/' );

require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/frontend.php';

if ( is_admin() ) {
	require_once __DIR__ . '/includes/admin.php';
}

/**
 * Nothing changes on a site until the owner saves settings: every feature
 * starts switched off. The one default we pick is to leave schema off when
 * an SEO plugin already prints it, to avoid duplicate markup.
 */
function nxsat_activate() {
	if ( false === get_option( NXSAT_OPTION, false ) ) {
		$defaults                   = nxsat_default_options();
		$defaults['schema_enabled'] = 0;
		add_option( NXSAT_OPTION, $defaults, '', false );
	}
	// Send the person who activated the plugin to the settings page, where one click applies the fixes.
	set_transient( 'nxsat_welcome', 1, 60 );
}
register_activation_hook( __FILE__, 'nxsat_activate' );

function nxsat_deactivate() {
	delete_transient( 'nxsat_llms' );
}
register_deactivation_hook( __FILE__, 'nxsat_deactivate' );
